var gnHeader = document.getElementsByClassName('gn-header')[0],
    gnList = document.getElementsByClassName('gn-list')[0],
    gnListMore = document.getElementsByClassName('gn-list-more')[0];

gnListMore.onclick = function () {
    if(document.getElementsByClassName('gn-list-active')[0]) {
        gnList.classList.remove('gn-list-active');
    }else {
        gnList.classList.add('gn-list-active');
    }
}